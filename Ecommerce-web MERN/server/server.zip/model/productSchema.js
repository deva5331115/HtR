import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
    id: {
        type: String,
        unique: true
    },
    url: String,
    detailUrl: String,
    title: Object,
    price: Object,
    quantity: Number,
    description: String,
    discount: String,
    tagline: String
});

// Pre-save middleware to auto-increment the 'id' field
productSchema.pre('save', function (next) {
    const product = this;
    if (product.isNew) {
        mongoose.model('product', productSchema)
            .countDocuments()
            .then(count => {
                product.id = count + 1;
                next();
            })
            .catch(err => next(err));
    } else {
        next();
    }
});

const products = mongoose.model('product', productSchema);

export default products;